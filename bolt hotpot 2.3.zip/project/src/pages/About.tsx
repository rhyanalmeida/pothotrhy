import React from 'react';
import MapSection from '../components/MapSection';
import { EditProvider } from '../contexts/EditContext';
import EditableText from '../components/EditableText';
import EditToggle from '../components/EditToggle';

const About = () => {
  return (
    <EditProvider>
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto py-12 px-4">
          <div className="bg-white rounded-lg shadow-md p-6">
            <EditableText
              text="About Hot Pot One"
              onTextChange={() => {}}
              className="text-3xl font-bold text-brand-brown-600 mb-6"
              as="h1"
            />
            <div className="prose max-w-none">
              <EditableText
                text="Welcome to Hot Pot One, Quincy's premier destination for authentic hot pot dining. 
                Our restaurant brings the traditional Chinese hot pot experience to life, offering 
                a unique and interactive dining adventure where you become the chef of your own meal."
                onTextChange={() => {}}
                className="text-lg mb-4"
              />
              <EditableText
                text="At Hot Pot One, we take pride in serving only the freshest ingredients. Our broths 
                are made daily using traditional recipes, and our meat, seafood, and vegetables are 
                carefully selected to ensure the highest quality dining experience."
                onTextChange={() => {}}
                className="text-lg mb-4"
              />
              <EditableText
                text="Whether you're new to hot pot or a seasoned enthusiast, our friendly staff is here 
                to guide you through the experience and ensure you have an unforgettable meal."
                onTextChange={() => {}}
                className="text-lg mb-4"
              />
            </div>
          </div>
        </div>
        <MapSection />
      </div>
      <EditToggle />
    </EditProvider>
  );
};

export default About;