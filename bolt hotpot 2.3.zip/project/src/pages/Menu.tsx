import React, { useState } from 'react';
import { EditProvider } from '../contexts/EditContext';
import { AlertCircle } from 'lucide-react';
import EditToggle from '../components/EditToggle';
import SEOHelmet from '../components/SEOHelmet';

const MenuTab = ({ 
  title, 
  isActive, 
  onClick 
}: { 
  title: string; 
  isActive: boolean; 
  onClick: () => void;
}) => (
  <button
    onClick={onClick}
    className={`px-6 py-3 text-lg font-bold ${
      isActive 
        ? 'bg-white text-red-600 border-t-2 border-red-600' 
        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
    } rounded-t-lg transition-colors`}
  >
    {title}
  </button>
);

const BeverageContent = () => {
  return (
    <div className="min-h-screen bg-white">
      <div className="relative">
        <div className="absolute inset-0 flex flex-col items-center p-8">
          <div className="w-full max-w-5xl">
            <h2 className="text-3xl font-bold text-red-600 mb-6">Beverage Menu</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <img
                src="https://i.ibb.co/PZk7dtRN/Wine-Menu-2025-Final-1.png"
                alt="Wine Menu Page 1"
                className="w-full rounded-lg shadow-lg"
              />
              <img
                src="https://i.ibb.co/gbQDjpC0/Wine-Menu-2025-Final-2.png"
                alt="Wine Menu Page 2"
                className="w-full rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const HotpotBuffetContent = () => {
  return (
    <div className="min-h-screen bg-white">
      <div className="relative">
        <div className="absolute inset-0 flex flex-col items-center p-8">
          {/* Rules Section */}
          <div className="w-full max-w-5xl mb-8">
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <AlertCircle className="w-6 h-6 text-brand-brown-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-lg font-semibold text-brand-brown-600 mb-2">
                    Hotpot Buffet Rules
                  </h3>
                  <div className="prose text-gray-700">
                    <p>The buffet time limit is 100 minutes after the first order is submitted. The whole party must order the same-priced buffet course. All uneaten/unfinished items will be charged $15.00 USD per plate to your bill. Takeout is not allowed for any leftovers, and no substitutions are permitted. Please request the manager for any special needs or allergy concerns. Additional rules may apply, but are not limited to those listed above.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Menu Images */}
          <div className="w-full max-w-5xl">
            <h2 className="text-3xl font-bold text-red-600 mb-6">Hotpot Buffet Menu</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <img
                src="https://i.ibb.co/r2FVDs3w/Price-Menu-2024-11-copy-1.png"
                alt="Hotpot Buffet Menu Page 1"
                className="w-full rounded-lg shadow-lg"
              />
              <img
                src="https://i.ibb.co/0yDDLRGs/Price-Menu-2024-11-copy-2.png"
                alt="Hotpot Buffet Menu Page 2"
                className="w-full rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const DimSumContent = () => {
  return (
    <div className="min-h-screen bg-white">
      <div className="relative">
        <div className="absolute inset-0 flex flex-col items-center p-8">
          <div className="w-full max-w-5xl">
            <h2 className="text-3xl font-bold text-red-600 mb-6">Dim Sum Menu</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <img
                src="https://i.ibb.co/PsQJG1Yy/Dim-Sum-Menu-with-Photo-1.png"
                alt="Dim Sum Menu Page 1"
                className="w-full rounded-lg shadow-lg"
              />
              <img
                src="https://i.ibb.co/j98LPWbT/Dim-Sum-Menu-with-Photo-2.png"
                alt="Dim Sum Menu Page 2"
                className="w-full rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Menu = () => {
  const [activeTab, setActiveTab] = useState('beverage');

  return (
    <EditProvider>
      <SEOHelmet
        title="Menu - Hot Pot & Dim Sum"
        description="Explore our extensive menu featuring authentic hot pot broths, fresh ingredients, dim sum specialties, and refreshing beverages. All you can eat options available."
        path="/menu"
      />
      <div className="min-h-screen bg-gray-50">
        {/* Allergy Warning */}
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mx-4 mt-4 mb-2">
          <div className="flex items-start">
            <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
            <div className="ml-3">
              <p className="text-sm text-red-700">
                <span className="font-bold">Allergy Warning:</span> Our dishes may contain common allergens such as peanuts, shellfish, and gluten. Please inform our staff of any allergies before ordering.
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-center gap-2 bg-gray-50 px-4 pt-4">
          <MenuTab
            title="Beverage Menu"
            isActive={activeTab === 'beverage'}
            onClick={() => setActiveTab('beverage')}
          />
          <MenuTab
            title="Hotpot Buffet Menu"
            isActive={activeTab === 'allyoucaneat'}
            onClick={() => setActiveTab('allyoucaneat')}
          />
          <MenuTab
            title="Dim Sum Menu"
            isActive={activeTab === 'dimsum'}
            onClick={() => setActiveTab('dimsum')}
          />
        </div>

        {activeTab === 'beverage' && <BeverageContent />}
        {activeTab === 'allyoucaneat' && <HotpotBuffetContent />}
        {activeTab === 'dimsum' && <DimSumContent />}
        <EditToggle />
      </div>
    </EditProvider>
  );
};

export default Menu;