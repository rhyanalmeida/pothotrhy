import React, { useState, useEffect } from 'react';
import { FileUp, Plus, Trash2 } from 'lucide-react';
import { EditProvider } from '../contexts/EditContext';
import { useEdit } from '../contexts/EditContext';
import EditableText from '../components/EditableText';
import EditToggle from '../components/EditToggle';
import SEOHelmet from '../components/SEOHelmet';
import imageCompression from 'browser-image-compression';
import { initializeDatabase, getStore } from '../utils/indexedDB';

interface GalleryImage {
  id: number;
  dataUrl: string;
  alt: string;
  timestamp: number;
}

const STORE_NAME = 'gallery';

const initDB = () => {
  return initializeDatabase('GalleryDB', 'gallery', { keyPath: 'id' });
};

const convertToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

// Generate a unique numeric ID
const generateUniqueId = () => {
  return Date.now() + Math.floor(Math.random() * 1000);
};

const GalleryContent = () => {
  const { isAdmin } = useEdit();
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [db, setDB] = useState<IDBDatabase | null>(null);

  useEffect(() => {
    initDB()
      .then((database) => {
        setDB(database);
        loadImages(database);
      })
      .catch((error) => {
        console.error('Error initializing database:', error);
        setError('Failed to initialize gallery storage');
      });

    return () => {
      if (db) {
        db.close();
      }
    };
  }, []);

  const loadImages = async (database: IDBDatabase) => {
    try {
      const store = getStore(database, 'gallery');
      const index = store.index('timestamp');
      
      return new Promise<void>((resolve, reject) => {
        const request = index.openCursor(null, 'prev');
        const loadedImages: GalleryImage[] = [];

        request.onsuccess = (event) => {
          const cursor = (event.target as IDBRequest).result;
          if (cursor) {
            loadedImages.push(cursor.value);
            cursor.continue();
          } else {
            setImages(loadedImages);
            resolve();
          }
        };

        request.onerror = () => reject(new Error('Failed to load images'));
      });
    } catch (error) {
      console.error('Error loading images:', error);
      setError('Failed to load images');
    }
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!db || !isAdmin) return;

    const files = event.target.files;
    if (!files || files.length === 0) return;

    setIsLoading(true);
    setError(null);

    try {
      const options = {
        maxSizeMB: 1,
        maxWidthOrHeight: 1920,
        useWebWorker: true
      };

      for (const file of Array.from(files)) {
        // Validate file type
        if (!file.type.startsWith('image/')) {
          throw new Error('Please upload only image files');
        }

        // Compress image
        const compressedFile = await imageCompression(file, options);
        
        // Convert to base64
        const dataUrl = await convertToBase64(compressedFile);

        // Save to IndexedDB
        const transaction = db.transaction([STORE_NAME], 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        
        const newImage: GalleryImage = {
          id: generateUniqueId(),
          dataUrl,
          alt: file.name.replace(/\.[^/.]+$/, ''),
          timestamp: Date.now()
        };

        await new Promise<void>((resolve, reject) => {
          const request = store.add(newImage);
          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
        });
      }

      // Reload images after successful upload
      await loadImages(db);
    } catch (error) {
      console.error('Error uploading images:', error);
      setError(error instanceof Error ? error.message : 'Failed to upload images');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteImage = async (id: number) => {
    if (!db || !isAdmin || !window.confirm('Are you sure you want to delete this image?')) return;

    try {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      
      await new Promise<void>((resolve, reject) => {
        const request = store.delete(id);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });

      await loadImages(db);
    } catch (error) {
      console.error('Error deleting image:', error);
      setError('Failed to delete image');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-12 px-4">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center mb-6">
            <EditableText
              text="Our Gallery"
              onTextChange={() => {}}
              className="text-3xl font-bold text-brand-brown-600"
              as="h1"
            />
            {isAdmin && (
              <label className={`flex items-center gap-2 bg-brand-brown-600 text-white px-4 py-2 rounded-lg cursor-pointer hover:bg-brand-brown-700 transition-colors ${
                isLoading ? 'opacity-50 cursor-not-allowed' : ''
              }`}>
                <Plus size={20} />
                {isLoading ? 'Uploading...' : 'Add Photos'}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  multiple
                  disabled={isLoading}
                />
              </label>
            )}
          </div>

          {error && (
            <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {images.map((image) => (
              <div key={image.id} className="group relative aspect-w-16 aspect-h-9">
                <img
                  src={image.dataUrl}
                  alt={image.alt}
                  className="w-full h-full object-cover rounded-lg"
                  loading="lazy"
                />
                {isAdmin && (
                  <button
                    onClick={() => handleDeleteImage(image.id)}
                    className="absolute top-2 right-2 bg-red-600 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-700"
                    aria-label="Delete image"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
            ))}
          </div>

          {images.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <FileUp className="w-12 h-12 mx-auto mb-4" />
              <p>No images yet. {isAdmin ? 'Click "Add Photos" to get started.' : ''}</p>
            </div>
          )}
        </div>
      </div>
      <EditToggle />
    </div>
  );
};

const Gallery = () => {
  return (
    <EditProvider>
      <SEOHelmet
        title="Gallery"
        description="View our gallery of delicious hot pot dishes, fresh ingredients, and dining experience at Hot Pot One in Quincy, MA."
        path="/gallery"
      />
      <GalleryContent />
    </EditProvider>
  );
};

export default Gallery;