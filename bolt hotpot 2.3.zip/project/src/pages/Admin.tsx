import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Save, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useEdit } from '../contexts/EditContext';
import SEOHelmet from '../components/SEOHelmet';
import { handleSupabaseError } from '../lib/supabase';

const AdminPanel = () => {
  const { isAdmin } = useEdit();
  const navigate = useNavigate();
  const [announcement, setAnnouncement] = useState('');
  const [isPublic, setIsPublic] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }

    const fetchAnnouncement = async () => {
      try {
        const { data, error } = await supabase
          .from('announcements')
          .select('content, is_public')
          .eq('id', 'current')
          .single();

        if (error) {
          throw error;
        }
        
        if (data) {
          setAnnouncement(data.content);
          setIsPublic(data.is_public);
        }
      } catch (err) {
        console.error('Error fetching announcement:', err);
        setError(handleSupabaseError(err));
      }
    };

    fetchAnnouncement();
  }, [isAdmin, navigate]);

  const handleSave = async () => {
    if (!announcement.trim()) {
      setError('Announcement cannot be empty');
      return;
    }

    setIsSaving(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const { error: authError } = await supabase.auth.getSession();
      if (authError) throw authError;

      const { error } = await supabase
        .from('announcements')
        .upsert({
          id: 'current',
          content: announcement.trim(),
          is_public: isPublic,
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'id'
        });

      if (error) throw error;
      
      setSuccessMessage('Announcement saved successfully');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      console.error('Error saving announcement:', err);
      setError(handleSupabaseError(err));
    } finally {
      setIsSaving(false);
    }
  };

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <SEOHelmet
        title="Admin Panel"
        description="Admin panel for Hot Pot One website management"
        path="/admin"
      />
      
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h1 className="text-3xl font-bold text-brand-brown-600 mb-8">Admin Panel</h1>

          <div className="space-y-8">
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-800">Manage Announcement</h2>
                <button
                  onClick={() => setIsPublic(!isPublic)}
                  disabled={isSaving}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                    isPublic 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-gray-100 text-gray-700'
                  } hover:bg-opacity-80 transition-colors`}
                >
                  {isPublic ? (
                    <>
                      <Eye size={18} />
                      Public
                    </>
                  ) : (
                    <>
                      <EyeOff size={18} />
                      Private
                    </>
                  )}
                </button>
              </div>

              {error && (
                <div className="mb-4 flex items-start gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
                  <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              {successMessage && (
                <div className="mb-4 text-green-600 bg-green-50 p-3 rounded-lg">
                  {successMessage}
                </div>
              )}

              <div className="space-y-4">
                <textarea
                  value={announcement}
                  onChange={(e) => setAnnouncement(e.target.value)}
                  rows={5}
                  className="w-full p-4 border rounded-lg focus:ring-2 focus:ring-brand-brown-200 focus:border-brand-brown-400"
                  placeholder="Enter announcement text..."
                  disabled={isSaving}
                />

                <button
                  onClick={handleSave}
                  disabled={isSaving}
                  className={`flex items-center gap-2 bg-brand-brown-600 text-white px-6 py-3 rounded-lg hover:bg-brand-brown-700 transition-colors ${
                    isSaving ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  <Save size={18} />
                  {isSaving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;