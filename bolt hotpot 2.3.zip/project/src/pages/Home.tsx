import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Utensils, Camera } from 'lucide-react';
import { EditProvider } from '../contexts/EditContext';
import EditableContent from '../components/EditableContent';
import Footer from '../components/Footer';
import ImageSlideshow from '../components/ImageSlideshow';
import SEOHelmet from '../components/SEOHelmet';
import { supabase } from '../lib/supabase';

const PublicAnnouncement = () => {
  const [announcement, setAnnouncement] = React.useState<string | null>(null);

  React.useEffect(() => {
    const fetchAnnouncement = async () => {
      try {
        const { data, error } = await supabase
          .from('announcements')
          .select('content')
          .eq('id', 'current')
          .eq('is_public', true)
          .single();

        if (error) throw error;
        if (data) {
          setAnnouncement(data.content);
        }
      } catch (err) {
        console.error('Error fetching announcement:', err);
      }
    };

    fetchAnnouncement();
  }, []);

  if (!announcement) return null;

  return (
    <div className="bg-brand-brown-50 py-6">
      <div className="max-w-6xl mx-auto px-4">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <h2 className="text-2xl font-bold text-brand-brown-600 mb-4">Announcements</h2>
          <p className="text-gray-700">{announcement}</p>
        </div>
      </div>
    </div>
  );
};

const MenuSection = () => {
  return (
    <div className="bg-brand-brown-50 py-16">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-brand-brown-600 mb-4">Our Menus</h2>
          <EditableContent
            id="menu-description"
            defaultContent="Explore our carefully curated selection of hot pot broths, fresh ingredients, dim sum specialties, and refreshing beverages."
            className="text-lg text-gray-600 max-w-2xl mx-auto mb-8"
          />
          <Link
            to="/menu"
            className="inline-flex items-center gap-2 bg-brand-brown-600 text-white px-8 py-4 rounded-lg hover:bg-brand-brown-700 transition-colors shadow-md hover:shadow-lg"
          >
            <Utensils className="w-6 h-6" />
            <span className="text-lg font-semibold">View Our Menus</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

const GallerySection = () => {
  return (
    <div className="bg-white py-16">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-brand-brown-600 mb-4">Our Gallery</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Take a visual journey through our delicious dishes and vibrant dining atmosphere
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Link to="/gallery" className="group">
            <div className="relative aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
              <img
                src="https://i.postimg.cc/05pLKYrH/IMG-1052.jpg"
                alt="Hot Pot Dish"
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500 brightness-105"
              />
              <div className="absolute inset-0 bg-black/10 group-hover:bg-black/5 transition-colors" />
            </div>
          </Link>
          <Link to="/gallery" className="group">
            <div className="relative aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
              <img
                src="https://i.postimg.cc/mDd1mzrx/IMG-1035-1.jpg"
                alt="Hot Pot Ingredients"
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500 brightness-105"
              />
              <div className="absolute inset-0 bg-black/10 group-hover:bg-black/5 transition-colors" />
            </div>
          </Link>
          <Link to="/gallery" className="group">
            <div className="relative aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
              <img
                src="https://i.postimg.cc/rwn6FqzV/IMG-1011.jpg"
                alt="Hot Pot Experience"
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500 brightness-105"
              />
              <div className="absolute inset-0 bg-black/10 group-hover:bg-black/5 transition-colors" />
            </div>
          </Link>
          <Link to="/gallery" className="group">
            <div className="relative aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
              <img
                src="https://i.postimg.cc/d3k3n5Xd/coverim.jpg"
                alt="Hot Pot Cover Image"
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500 brightness-105"
              />
              <div className="absolute inset-0 bg-black/10 group-hover:bg-black/5 transition-colors" />
            </div>
          </Link>
        </div>

        <div className="text-center">
          <Link
            to="/gallery"
            className="inline-flex items-center gap-2 bg-brand-brown-600 text-white px-8 py-3 rounded-lg hover:bg-brand-brown-700 transition-colors"
          >
            <Camera className="w-5 h-5" />
            View Full Gallery
          </Link>
        </div>
      </div>
    </div>
  );
};

const Home = () => {
  return (
    <EditProvider>
      <SEOHelmet
        title="Best Hot Pot & Dim Sum Restaurant"
        description="Experience authentic Chinese hot pot and dim sum at Hot Pot One in Quincy, MA. Fresh ingredients, traditional broths, and a cozy dining atmosphere. Order online or make a reservation today!"
        path="/"
      />
      <div className="min-h-screen">
        <div className="relative h-screen">
          <ImageSlideshow />
          
          <div className="absolute inset-0 flex flex-col justify-center items-center px-4 sm:px-6 lg:px-8 z-10">
            <div className="text-center bg-black/15 backdrop-blur-[1px] p-8 rounded-lg">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 leading-tight text-shadow drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)]">
                Best Hotpot & Dim Sum<br />
                Restaurant in Quincy, MA
              </h1>
              <p className="text-xl font-bold text-white mb-8 max-w-2xl mx-auto text-shadow drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)]">
                Enjoy handcrafted broths, fresh ingredients, and delicious dim sum, 
                right here in Quincy, MA.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <a
                  href="https://www.hotpotonema.com/egj72kti/hotpot-one-quincy-02171/order-online"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto bg-red-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-red-700 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                >
                  Order Online
                </a>
                <a
                  href="https://www.mealage.com/new288/2m.jsp?catering=null&sessionid=1737639852495A1721561193185rffvxxztlmiesnrtpmdjffmnzfpa&id=1168"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto bg-brand-yellow-400 text-brand-brown-700 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-brand-yellow-500 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                >
                  Make a Reservation
                </a>
              </div>
            </div>
          </div>
        </div>

        <PublicAnnouncement />
        <MenuSection />
        <GallerySection />

        <div className="bg-brand-brown-600 text-white py-16 text-center">
          <h2 className="text-4xl font-bold mb-12">Stay Connected</h2>
          <div className="flex justify-center gap-8">
            <a
              href="https://instagram.com/hotpotonequincy"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white p-4 rounded-full hover:bg-gray-100 transition-colors transform hover:-translate-y-1"
            >
              <Instagram className="w-8 h-8 text-brand-brown-600" />
            </a>
          </div>
        </div>

        <Footer />
      </div>
    </EditProvider>
  );
};

export default Home;