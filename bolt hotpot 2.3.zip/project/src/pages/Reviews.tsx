import React, { useState, useEffect } from 'react';
import { Star, Mail } from 'lucide-react';
import { Review } from '../types';
import SEOHelmet from '../components/SEOHelmet';
import { initializeDatabase, getStore } from '../utils/indexedDB';

const Reviews = () => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [db, setDB] = useState<IDBDatabase | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    rating: 5,
    content: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const init = async () => {
      try {
        const database = await initializeDatabase('ReviewsDB', 'reviews', { 
          keyPath: 'id' 
        });
        setDB(database);
        await loadReviews(database);
      } catch (error) {
        console.error('Error initializing database:', error);
        setError('Failed to initialize reviews storage');
      }
    };

    init();

    return () => {
      if (db) {
        db.close();
      }
    };
  }, []);

  const loadReviews = async (database: IDBDatabase) => {
    try {
      const store = getStore(database, 'reviews');
      const index = store.index('timestamp');
      
      return new Promise<void>((resolve, reject) => {
        const request = index.openCursor(null, 'prev');
        const loadedReviews: Review[] = [];

        request.onsuccess = (event) => {
          const cursor = (event.target as IDBRequest).result;
          if (cursor) {
            loadedReviews.push(cursor.value);
            cursor.continue();
          } else {
            setReviews(loadedReviews);
            resolve();
          }
        };

        request.onerror = () => reject(request.error);
      });
    } catch (error) {
      console.error('Error loading reviews:', error);
      setError('Failed to load reviews');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db || isSubmitting) return;

    setIsSubmitting(true);
    setError(null);

    try {
      const newReview: Review = {
        id: crypto.randomUUID(), // Generate a unique ID
        author: formData.name,
        content: formData.content,
        rating: formData.rating,
        date: new Date().toISOString(),
        timestamp: Date.now()
      };

      const transaction = db.transaction(['reviews'], 'readwrite');
      const store = transaction.objectStore('reviews');
      
      await new Promise<void>((resolve, reject) => {
        const request = store.add(newReview);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });

      // Reset form
      setFormData({
        name: '',
        rating: 5,
        content: ''
      });

      // Reload reviews
      await loadReviews(db);
    } catch (error) {
      console.error('Error saving review:', error);
      setError('Failed to save review. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStars = (rating: number, interactive = false) => {
    return [...Array(5)].map((_, index) => (
      <Star
        key={index}
        className={`w-6 h-6 ${
          index < rating 
            ? 'text-yellow-400 fill-current' 
            : 'text-gray-300'
        } ${interactive ? 'cursor-pointer hover:scale-110 transition-transform' : ''}`}
        onClick={interactive ? () => setFormData(prev => ({ ...prev, rating: index + 1 })) : undefined}
      />
    ));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <SEOHelmet
        title="Customer Reviews"
        description="Read authentic customer reviews of Hot Pot One in Quincy, MA. Share your dining experience and help others discover the best hot pot and dim sum restaurant in the area."
        path="/reviews"
      />
      <div className="max-w-7xl mx-auto py-12 px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Review Form Section */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-3xl font-bold text-brand-brown-600 mb-6">Write a Review</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-brand-brown-500 focus:border-brand-brown-500"
                  required
                  disabled={isSubmitting}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Rating
                </label>
                <div className="flex gap-1">
                  {renderStars(formData.rating, !isSubmitting)}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Your Review
                </label>
                <textarea
                  value={formData.content}
                  onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                  rows={4}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-brand-brown-500 focus:border-brand-brown-500"
                  required
                  disabled={isSubmitting}
                />
              </div>

              {error && (
                <div className="text-sm text-red-600">
                  {error}
                </div>
              )}
              
              <button
                type="submit"
                className={`w-full bg-brand-brown-600 text-white py-3 rounded-md transition-colors ${
                  isSubmitting 
                    ? 'opacity-50 cursor-not-allowed' 
                    : 'hover:bg-brand-brown-700'
                }`}
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Submitting...' : 'Submit Review'}
              </button>
            </form>
          </div>

          {/* Contact Section */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-3xl font-bold text-brand-brown-600 mb-6">Contact Us</h2>
            <div className="space-y-6">
              <p className="text-gray-600">
                Have questions or feedback? We'd love to hear from you! 
                Click the button below to send us an email.
              </p>
              
              <a
                href="mailto:hotpotone9@gmail.com"
                className="inline-flex items-center gap-2 bg-brand-brown-600 text-white px-6 py-3 rounded-lg hover:bg-brand-brown-700 transition-colors"
              >
                <Mail className="w-5 h-5" />
                Contact Us
              </a>
            </div>
          </div>
        </div>

        {/* Reviews Display Section */}
        <div className="mt-12 bg-white rounded-lg shadow-md p-6">
          <h2 className="text-3xl font-bold text-brand-brown-600 mb-6">Customer Reviews</h2>
          <div className="space-y-8">
            {reviews.map((review) => (
              <div 
                key={review.id}
                className="border-b border-gray-200 last:border-0 pb-6 last:pb-0"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-semibold text-gray-800">{review.author}</h3>
                  <span className="text-sm text-gray-500">
                    {new Date(review.date).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex mb-3">{renderStars(review.rating)}</div>
                <p className="text-gray-600 leading-relaxed">{review.content}</p>
              </div>
            ))}

            {reviews.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <p>No reviews yet. Be the first to share your experience!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reviews;