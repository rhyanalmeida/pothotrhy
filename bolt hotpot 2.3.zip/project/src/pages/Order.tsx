import React, { useState } from 'react';
import MapSection from '../components/MapSection';
import { EditProvider } from '../contexts/EditContext';
import EditableText from '../components/EditableText';
import EditToggle from '../components/EditToggle';
import { ExternalLink } from 'lucide-react';

const Order = () => {
  const [orderLink, setOrderLink] = useState('https://www.example.com/order');
  const [isEditingLink, setIsEditingLink] = useState(false);

  const handleLinkEdit = () => {
    const newLink = prompt('Enter the order link:', orderLink);
    if (newLink) {
      setOrderLink(newLink);
    }
  };

  return (
    <EditProvider>
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto py-12 px-4">
          <div className="bg-white rounded-lg shadow-md p-6">
            <EditableText
              text="Order Online"
              onTextChange={() => {}}
              className="text-3xl font-bold text-brand-brown-600 mb-6"
              as="h1"
            />
            <div className="text-center">
              <EditableText
                text="Order directly through our online platform:"
                onTextChange={() => {}}
                className="text-lg mb-8"
              />

              <div className="flex flex-col items-center space-y-8 mb-12">
                <a
                  href={orderLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-brand-yellow-500 text-brand-brown-700 px-8 py-4 rounded-lg text-xl hover:bg-brand-yellow-600 transition-colors font-semibold shadow-md"
                >
                  <ExternalLink size={24} />
                  Order Now
                </a>
                <button
                  onClick={handleLinkEdit}
                  className="text-sm text-brand-brown-600 hover:text-brand-brown-700 underline"
                >
                  Edit Order Link
                </button>
              </div>

              <div className="grid grid-cols-1 gap-6">
                <a
                  href="tel:857-387-2000"
                  className="block p-6 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <h3 className="text-xl font-semibold mb-2">Call Directly</h3>
                  <p className="text-gray-600">(857)-387-2000</p>
                </a>
              </div>
            </div>
          </div>
        </div>
        <MapSection />
      </div>
      <EditToggle />
    </EditProvider>
  );
};

export default Order;