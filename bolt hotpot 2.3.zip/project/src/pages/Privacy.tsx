import React from 'react';
import SEOHelmet from '../components/SEOHelmet';
import Footer from '../components/Footer';

const Privacy = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <SEOHelmet
        title="Privacy Policy"
        description="Read our privacy policy to understand how Hot Pot One collects, uses, and protects your personal information. Learn about our commitment to your privacy and data security."
        path="/privacy"
      />
      
      <div className="max-w-4xl mx-auto py-12 px-4">
        <div className="bg-white rounded-lg shadow-md p-8">
          <h1 className="text-3xl font-bold text-brand-brown-600 mb-8">Privacy Policy</h1>
          
          <div className="prose max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-brand-brown-600 mb-4">Introduction</h2>
              <p className="mb-4">
                At Hot Pot One, we take your privacy seriously. This Privacy Policy explains how we collect, 
                use, and protect your personal information when you visit our website or dine at our restaurant.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-brand-brown-600 mb-4">Information We Collect</h2>
              <p className="mb-4">We collect information that you provide directly to us, including:</p>
              <ul className="list-disc pl-6 mb-4">
                <li>Name and contact information when making reservations</li>
                <li>Email address when signing up for our newsletter</li>
                <li>Dining preferences and dietary restrictions</li>
                <li>Payment information when processing transactions</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-brand-brown-600 mb-4">How We Use Your Information</h2>
              <p className="mb-4">We use the information we collect to:</p>
              <ul className="list-disc pl-6 mb-4">
                <li>Process your reservations and orders</li>
                <li>Send you marketing communications (with your consent)</li>
                <li>Improve our services and customer experience</li>
                <li>Comply with legal obligations</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-brand-brown-600 mb-4">Data Security</h2>
              <p className="mb-4">
                We implement appropriate security measures to protect your personal information 
                from unauthorized access, disclosure, or misuse.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-brand-brown-600 mb-4">Your Rights</h2>
              <p className="mb-4">You have the right to:</p>
              <ul className="list-disc pl-6 mb-4">
                <li>Access your personal information</li>
                <li>Request correction of inaccurate information</li>
                <li>Request deletion of your information</li>
                <li>Opt-out of marketing communications</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-brand-brown-600 mb-4">Contact Us</h2>
              <p className="mb-4">
                If you have any questions about our Privacy Policy, please contact us at:
              </p>
              <p className="mb-4">
                Email: hotpot9@gmail.com<br />
                Phone: (857) 387-2000<br />
                Address: 9 Billings Road, Quincy, MA 02171
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-brand-brown-600 mb-4">Updates to This Policy</h2>
              <p>
                We may update this Privacy Policy from time to time. The latest version will always 
                be posted on this page with the effective date.
              </p>
            </section>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default Privacy;