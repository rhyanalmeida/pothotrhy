import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/supabase';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  },
  global: {
    headers: {
      'x-application-name': 'hotpotone'
    }
  }
});

// Add error handling for common Supabase errors
supabase.auth.onAuthStateChange((event, session) => {
  if (event === 'SIGNED_OUT') {
    // Clear any cached data
    localStorage.removeItem('supabase.auth.token');
  }
});

export const handleSupabaseError = (error: any) => {
  console.error('Supabase error:', error);
  
  if (error.code === '42501') {
    return 'You need to be logged in as an admin to perform this action.';
  }
  
  if (error.code === 'PGRST301') {
    return 'Database connection error. Please try again later.';
  }

  if (error.message?.includes('JWT')) {
    return 'Your session has expired. Please log in again.';
  }
  
  return 'An unexpected error occurred. Please try again.';
};