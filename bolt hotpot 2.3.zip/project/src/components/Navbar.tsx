import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-black text-white sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center">
            <img
              src="https://i.postimg.cc/rww59HvW/NEW-Hot-Pot-One-logo-white-text-trans.png"
              alt="Hot Pot One"
              className="h-16 w-auto transform hover:scale-105 transition-transform duration-200"
            />
          </Link>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-4">
              <Link to="/" className="hover:bg-gray-900 px-3 py-2 rounded-md text-sm">Home</Link>
              <Link to="/menu" className="hover:bg-gray-900 px-3 py-2 rounded-md text-sm">Menu</Link>
              <Link to="/gallery" className="hover:bg-gray-900 px-3 py-2 rounded-md text-sm">Gallery</Link>
              <Link to="/reviews" className="hover:bg-gray-900 px-3 py-2 rounded-md text-sm">Reviews</Link>
              <a
                href="https://www.hotpotonema.com/egj72kti/hotpot-one-quincy-02171/order-online"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:bg-gray-900 px-3 py-2 rounded-md text-sm"
              >
                Order Online
              </a>
            </div>
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md hover:bg-gray-900"
              aria-expanded={isOpen}
              aria-label="Toggle navigation menu"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>

      <div className={`md:hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-screen' : 'max-h-0 overflow-hidden'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          <Link 
            to="/" 
            className="block hover:bg-gray-900 px-3 py-2 rounded-md text-base font-medium"
            onClick={() => setIsOpen(false)}
          >
            Home
          </Link>
          <Link 
            to="/menu" 
            className="block hover:bg-gray-900 px-3 py-2 rounded-md text-base font-medium"
            onClick={() => setIsOpen(false)}
          >
            Menu
          </Link>
          <Link 
            to="/gallery" 
            className="block hover:bg-gray-900 px-3 py-2 rounded-md text-base font-medium"
            onClick={() => setIsOpen(false)}
          >
            Gallery
          </Link>
          <Link 
            to="/reviews" 
            className="block hover:bg-gray-900 px-3 py-2 rounded-md text-base font-medium"
            onClick={() => setIsOpen(false)}
          >
            Reviews
          </Link>
          <a
            href="https://www.hotpotonema.com/egj72kti/hotpot-one-quincy-02171/order-online"
            target="_blank"
            rel="noopener noreferrer"
            className="block hover:bg-gray-900 px-3 py-2 rounded-md text-base font-medium"
            onClick={() => setIsOpen(false)}
          >
            Order Online
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;