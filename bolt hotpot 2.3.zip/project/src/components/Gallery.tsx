import React, { useState } from 'react';
import { FileUp, Plus, Trash2 } from 'lucide-react';
import { useEdit } from '../contexts/EditContext';
import { uploadImage } from '../utils/cloudinary';

interface GalleryImage {
  id: number;
  url: string;
  alt: string;
}

const Gallery = () => {
  const { isAdmin } = useEdit();
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setIsLoading(true);
    setError(null);

    try {
      const uploadPromises = Array.from(files).map(async (file) => {
        const cloudinaryUrl = await uploadImage(file);
        return {
          id: Date.now() + Math.random(),
          url: cloudinaryUrl,
          alt: file.name.replace(/\.[^/.]+$/, '')
        };
      });

      const newImages = await Promise.all(uploadPromises);
      setImages(prev => [...prev, ...newImages]);
    } catch (error) {
      console.error('Error uploading images:', error);
      setError('Failed to upload images. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteImage = (id: number) => {
    if (!window.confirm('Are you sure you want to delete this image?')) return;
    setImages(prev => prev.filter(img => img.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-12 px-4">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-brand-brown-600">Our Gallery</h1>
            <label className="flex items-center gap-2 bg-brand-brown-600 text-white px-4 py-2 rounded-lg cursor-pointer hover:bg-brand-brown-700 transition-colors">
              <Plus size={20} />
              Add Photos
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                multiple
                disabled={isLoading}
              />
            </label>
          </div>

          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded-md mb-6">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {images.map((image) => (
              <div key={image.id} className="group relative aspect-w-16 aspect-h-9">
                <img
                  src={image.url}
                  alt={image.alt}
                  className="w-full h-full object-cover rounded-lg"
                />
                {isAdmin && (
                  <button
                    onClick={() => handleDeleteImage(image.id)}
                    className="absolute top-2 right-2 bg-red-600 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-700"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
            ))}
          </div>

          {images.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <FileUp className="w-12 h-12 mx-auto mb-4" />
              <p>No images yet. Click "Add Photos" to get started.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Gallery;