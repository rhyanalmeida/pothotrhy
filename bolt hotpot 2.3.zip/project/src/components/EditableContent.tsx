import React, { useState, useEffect } from 'react';
import { Pencil, Save, X } from 'lucide-react';
import { useEdit } from '../contexts/EditContext';
import { supabase } from '../lib/supabase';

interface EditableContentProps {
  id: string;
  defaultContent: string;
  className?: string;
}

const EditableContent: React.FC<EditableContentProps> = ({
  id,
  defaultContent,
  className = ''
}) => {
  const { isAdmin } = useEdit();
  const [isEditing, setIsEditing] = useState(false);
  const [content, setContent] = useState(defaultContent);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const { data, error } = await supabase
          .from('editable_content')
          .select('content')
          .eq('id', id)
          .single();

        if (error) throw error;
        if (data) {
          setContent(data.content);
        }
      } catch (err) {
        console.error('Error fetching content:', err);
      }
    };

    fetchContent();
  }, [id]);

  const handleSave = async () => {
    if (!content.trim()) return;
    
    setIsSaving(true);
    setError(null);

    try {
      const { error } = await supabase
        .from('editable_content')
        .upsert({
          id,
          content,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      setIsEditing(false);
    } catch (err) {
      console.error('Error saving content:', err);
      setError('Failed to save changes. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    setError(null);
  };

  if (isEditing) {
    return (
      <div className="relative">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className={`w-full p-4 border rounded-lg focus:ring-2 focus:ring-brand-brown-200 focus:border-brand-brown-400 ${className}`}
          rows={5}
          disabled={isSaving}
        />
        {error && (
          <p className="text-red-500 text-sm mt-2">{error}</p>
        )}
        <div className="flex justify-end gap-2 mt-2">
          <button
            onClick={handleCancel}
            className="flex items-center gap-1 px-3 py-1 text-gray-600 hover:text-gray-800 transition-colors"
            disabled={isSaving}
          >
            <X size={16} />
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={isSaving}
            className={`flex items-center gap-1 px-3 py-1 bg-brand-brown-600 text-white rounded hover:bg-brand-brown-700 transition-colors ${
              isSaving ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            <Save size={16} />
            {isSaving ? 'Saving...' : 'Save'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative group">
      <div className={className}>
        {content}
      </div>
      {isAdmin && (
        <button
          onClick={() => setIsEditing(true)}
          className="absolute -top-4 -right-4 p-2 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-50"
          aria-label="Edit content"
        >
          <Pencil size={16} className="text-brand-brown-600" />
        </button>
      )}
    </div>
  );
};

export default EditableContent