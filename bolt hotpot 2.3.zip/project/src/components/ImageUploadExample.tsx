import React, { useState } from 'react';
import ImageUpload from './ImageUpload';
import ImageUploadGrid from './ImageUploadGrid';

const ImageUploadExample = () => {
  const [singleImage, setSingleImage] = useState<string | null>(null);
  const [gridImages, setGridImages] = useState([
    { id: '1', url: '' },
    { id: '2', url: '' },
    { id: '3', url: '' }
  ]);

  const handleSingleUpload = (file: File) => {
    const url = URL.createObjectURL(file);
    setSingleImage(url);
  };

  const handleGridUpload = (id: string, file: File) => {
    const url = URL.createObjectURL(file);
    setGridImages(prev => 
      prev.map(img => 
        img.id === id ? { ...img, url } : img
      )
    );
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-4">Single Image Upload</h2>
        <ImageUpload
          onImageUpload={handleSingleUpload}
          currentImage={singleImage || undefined}
          className="max-w-md"
          label="Upload Profile Picture"
        />
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">Image Grid Upload</h2>
        <ImageUploadGrid
          images={gridImages}
          onImageUpload={handleGridUpload}
        />
      </div>
    </div>
  );
};

export default ImageUploadExample;