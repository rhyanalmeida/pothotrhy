import React, { useState } from 'react';
import { FileUp, X, Image as ImageIcon } from 'lucide-react';
import imageCompression from 'browser-image-compression';

interface ImageUploadProps {
  onImageUpload: (file: File) => void;
  currentImage?: string;
  className?: string;
  label?: string;
  maxSizeMB?: number;
  maxWidth?: number;
  maxHeight?: number;
  aspectRatio?: number;
}

const ImageUpload: React.FC<ImageUploadProps> = ({
  onImageUpload,
  currentImage,
  className = '',
  label = 'Upload Image',
  maxSizeMB = 1,
  maxWidth = 1920,
  maxHeight = 1080,
  aspectRatio
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [preview, setPreview] = useState<string | null>(currentImage || null);
  const [error, setError] = useState<string | null>(null);

  const handleFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file');
      return;
    }

    try {
      const options = {
        maxSizeMB,
        maxWidthOrHeight: Math.max(maxWidth, maxHeight),
        useWebWorker: true
      };

      const compressedFile = await imageCompression(file, options);
      
      // Create preview
      const previewUrl = URL.createObjectURL(compressedFile);
      setPreview(previewUrl);
      setError(null);

      // Call the callback with the compressed file
      onImageUpload(compressedFile);
    } catch (err) {
      setError('Error processing image. Please try again.');
      console.error('Error compressing image:', err);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);

    const file = e.dataTransfer.files[0];
    if (file) {
      handleFile(file);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFile(file);
    }
  };

  const clearImage = () => {
    setPreview(null);
    setError(null);
  };

  return (
    <div className={`relative ${className}`}>
      <div
        className={`relative border-2 ${
          isDragging ? 'border-brand-brown-500 bg-brand-brown-50' : 'border-dashed border-gray-300'
        } rounded-lg transition-colors ${aspectRatio ? 'aspect-w-16 aspect-h-9' : 'min-h-[200px]'}`}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
      >
        {preview ? (
          <div className="relative group">
            <img
              src={preview}
              alt="Preview"
              className="w-full h-full object-cover rounded-lg"
            />
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity flex items-center justify-center opacity-0 group-hover:opacity-100">
              <div className="flex gap-2">
                <label className="cursor-pointer bg-white text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-100 transition-colors">
                  Change
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleChange}
                    className="hidden"
                  />
                </label>
                <button
                  onClick={clearImage}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
            </div>
          </div>
        ) : (
          <label className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer group">
            <div className="flex flex-col items-center">
              <FileUp className="w-12 h-12 text-gray-400 mb-2 group-hover:text-brand-brown-500 transition-colors" />
              <span className="text-gray-600 group-hover:text-brand-brown-600 transition-colors">
                {label}
              </span>
              <span className="text-sm text-gray-400 mt-2">
                Drag & drop or click to upload
              </span>
              {error && (
                <span className="text-red-500 text-sm mt-2">{error}</span>
              )}
            </div>
            <input
              type="file"
              accept="image/*"
              onChange={handleChange}
              className="hidden"
            />
          </label>
        )}
      </div>
    </div>
  );
};

export default ImageUpload;