import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu } from 'lucide-react';

const BurgerMenuButton = () => {
  const navigate = useNavigate();

  return (
    <button
      onClick={() => navigate('/menu')}
      className="flex items-center gap-2 bg-brand-brown-600 text-white px-6 py-3 rounded-lg hover:bg-brand-brown-700 transition-colors shadow-md"
    >
      <Menu className="w-5 h-5" />
      <span>View Our Menus</span>
    </button>
  );
};

export default BurgerMenuButton;