import React from 'react';
import { Instagram, Mail, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';
import StaffPortal from './StaffPortal';
import AdminLogin from './AdminLogin';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12 relative">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <p className="mb-2">9 Billings Road</p>
            <p className="mb-2">Quincy, MA 02171</p>
            <a
              href="tel:+18573872000"
              className="mb-2 hover:text-brand-yellow-400 transition-colors inline-flex items-center gap-2"
            >
              <Phone size={20} />
              <span>(857) 387-2000</span>
            </a>
            <div className="mt-2">
              <a
                href="mailto:hotpot9@gmail.com"
                className="hover:text-brand-yellow-400 transition-colors inline-flex items-center gap-2"
                aria-label="Email us"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>

          {/* Hot Pot Hours */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Hours</h3>
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-bold text-brand-yellow-400 mb-2">Hot Pot Hours</h4>
                <p className="mb-2">Sunday - Monday: 12:00 PM - 10:00 PM</p>
                <p className="mb-2">Friday - Saturday: 12:00 PM - 11:00 PM</p>
              </div>
              <div>
                <h4 className="text-sm font-bold text-brand-yellow-400 mb-2">Dim Sum Hours</h4>
                <p className="mb-1">Monday - Friday: 11:00 AM - 3:00 PM</p>
                <p>Saturday - Sunday: 10:00 AM - 3:00 PM</p>
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <a
                href="https://instagram.com/hotpotonequincy"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-brand-yellow-400 transition-colors"
              >
                <Instagram size={24} />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-800">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <div className="flex items-center gap-4">
              <StaffPortal />
              <span className="hidden sm:block text-gray-600">|</span>
              <AdminLogin />
            </div>
          </div>
          <div className="text-center mt-4 space-y-2">
            <p className="text-sm text-gray-400">
              © {new Date().getFullYear()} Hot Pot One. All rights reserved.
            </p>
            <div className="flex justify-center items-center gap-4 text-sm text-gray-500">
              <p>Designed by Ace Web Designers</p>
              <span>|</span>
              <Link to="/privacy" className="hover:text-brand-yellow-400 transition-colors">
                Privacy Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;