import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Upload } from 'lucide-react';
import { useEdit } from '../contexts/EditContext';
import imageCompression from 'browser-image-compression';

const defaultSlides = [
  {
    id: 1,
    url: 'https://i.ibb.co/cKYqcxX2/Hotpot-Slide-1.png',
    alt: 'Hot Pot Slide 1'
  },
  {
    id: 2,
    url: 'https://i.ibb.co/pryvK4GT/Hotpot-Slide-2.png',
    alt: 'Hot Pot Slide 2'
  },
  {
    id: 3,
    url: 'https://i.ibb.co/yFdpqpNX/Hotpot-Slide-3.png',
    alt: 'Hot Pot Slide 3'
  },
  {
    id: 4,
    url: 'https://i.ibb.co/7d8thG2B/Hotpot-Slide-4.jpg',
    alt: 'Hot Pot Slide 4'
  },
  {
    id: 5,
    url: 'https://i.ibb.co/xtQtYtkB/hotpot-slide-5.jpg',
    alt: 'Hot Pot Slide 5'
  }
];

interface SlideImage {
  id: number;
  url: string;
  alt: string;
}

const ImageSlideshow: React.FC = () => {
  const { isAdmin } = useEdit();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [images, setImages] = useState<SlideImage[]>(defaultSlides);
  const [isLoading, setIsLoading] = useState(false);

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);

    try {
      const options = {
        maxSizeMB: 1,
        maxWidthOrHeight: 1920,
        useWebWorker: true
      };

      const compressedFile = await imageCompression(file, options);
      const url = URL.createObjectURL(compressedFile);
      
      const updatedImages = [...images];
      updatedImages[currentIndex] = {
        ...updatedImages[currentIndex],
        url
      };
      
      setImages(updatedImages);
    } catch (error) {
      console.error('Error processing image:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const navigate = (direction: 'prev' | 'next') => {
    if (isTransitioning || images.length <= 1) return;
    
    setIsTransitioning(true);
    if (direction === 'prev') {
      setCurrentIndex(current => (current - 1 + images.length) % images.length);
    } else {
      setCurrentIndex(current => (current + 1) % images.length);
    }
    setTimeout(() => setIsTransitioning(false), 1000);
  };

  useEffect(() => {
    if (images.length <= 1) return;
    
    const timer = setInterval(() => {
      if (!isTransitioning) {
        setIsTransitioning(true);
        setCurrentIndex(current => (current + 1) % images.length);
        setTimeout(() => setIsTransitioning(false), 1000);
      }
    }, 6000);

    return () => clearInterval(timer);
  }, [images.length, isTransitioning]);

  return (
    <div className="relative h-full overflow-hidden">
      {isAdmin && (
        <div className="absolute top-4 right-4 z-50">
          <label className={`flex items-center gap-2 bg-white/90 hover:bg-white text-gray-800 px-4 py-2 rounded-lg cursor-pointer transition-colors shadow-lg hover:shadow-xl backdrop-blur-sm ${
            isLoading ? 'opacity-50 cursor-not-allowed' : ''
          }`}>
            <Upload size={20} />
            {isLoading ? 'Uploading...' : 'Replace Image'}
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
              disabled={isLoading}
            />
          </label>
        </div>
      )}

      {images.map((image, index) => (
        <div
          key={image.id}
          className={`absolute inset-0 transition-all duration-1000 ease-out ${
            index === currentIndex ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
          }`}
          style={{
            zIndex: index === currentIndex ? 1 : 0
          }}
        >
          <img
            src={image.url}
            alt={image.alt}
            className="w-full h-full object-cover"
            loading={index === 0 ? 'eager' : 'lazy'}
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = defaultSlides[index].url;
            }}
          />
        </div>
      ))}

      <div className="absolute inset-0 bg-black bg-opacity-40" />

      {images.length > 1 && (
        <>
          <button
            onClick={() => navigate('prev')}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/75 transition-colors"
            disabled={isTransitioning}
          >
            <ChevronLeft size={24} />
          </button>
          <button
            onClick={() => navigate('next')}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/75 transition-colors"
            disabled={isTransitioning}
          >
            <ChevronRight size={24} />
          </button>
        </>
      )}

      {images.length > 1 && (
        <div className="absolute bottom-4 left-0 right-0">
          <div className="flex justify-center gap-2">
            {images.map((_, index) => (
              <button
                key={index}
                onClick={() => {
                  if (!isTransitioning) {
                    setIsTransitioning(true);
                    setCurrentIndex(index);
                    setTimeout(() => setIsTransitioning(false), 1000);
                  }
                }}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentIndex
                    ? 'bg-white w-4'
                    : 'bg-white/50 hover:bg-white/75'
                }`}
                disabled={isTransitioning}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageSlideshow;