import React from 'react';
import { FileUp } from 'lucide-react';
import { useEdit } from '../contexts/EditContext';

interface MenuCategory {
  id: string;
  title: string;
  pdfUrl: string | null;
}

interface BurgerMenuProps {
  onUpload: (categoryId: string, file: File) => void;
}

const BurgerMenu: React.FC<BurgerMenuProps> = ({ onUpload }) => {
  const { isEditing } = useEdit();

  const menuCategories: MenuCategory[] = [
    { id: 'beverage', title: 'Beverage Menu', pdfUrl: null },
    { id: 'dimsum', title: 'Dim Sum Menu', pdfUrl: null },
    { id: 'allyoucaneat', title: 'All You Can Eat Menu', pdfUrl: null }
  ];

  const handleFileChange = (categoryId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      onUpload(categoryId, file);
    } else {
      alert('Please upload a PDF file');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold text-brand-brown-600 mb-6">Our Menus</h2>
      <div className="grid gap-4">
        {menuCategories.map((category) => (
          <div
            key={category.id}
            className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-800">{category.title}</h3>
              {isEditing ? (
                <label className="cursor-pointer">
                  <FileUp className="w-5 h-5 text-brand-brown-600 hover:text-brand-brown-700" />
                  <input
                    type="file"
                    accept="application/pdf"
                    onChange={(e) => handleFileChange(category.id, e)}
                    className="hidden"
                  />
                </label>
              ) : category.pdfUrl && (
                <a
                  href={category.pdfUrl}
                  download={`${category.title}.pdf`}
                  className="text-brand-brown-600 hover:text-brand-brown-700 text-sm font-medium"
                >
                  Download PDF
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BurgerMenu;