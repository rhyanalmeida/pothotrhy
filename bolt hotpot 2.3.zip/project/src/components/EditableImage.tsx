import React from 'react';
import { Upload } from 'lucide-react';
import { useEdit } from '../contexts/EditContext';
import imageCompression from 'browser-image-compression';

interface EditableImageProps {
  src: string;
  alt: string;
  className?: string;
  onImageChange: (newUrl: string, file?: File) => void;
}

const EditableImage: React.FC<EditableImageProps> = ({
  src,
  alt,
  className = '',
  onImageChange
}) => {
  const { isEditing } = useEdit();

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const options = {
        maxSizeMB: 1,
        maxWidthOrHeight: 1920,
        useWebWorker: true
      };

      const compressedFile = await imageCompression(file, options);
      const imageUrl = URL.createObjectURL(compressedFile);
      onImageChange(imageUrl, compressedFile);
    } catch (error) {
      console.error('Error compressing image:', error);
    }
  };

  return (
    <div className="relative group">
      <img src={src} alt={alt} className={className} />
      {isEditing && (
        <label className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
          <div className="text-white flex flex-col items-center">
            <Upload className="w-8 h-8 mb-2" />
            <span>Change Image</span>
          </div>
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleImageUpload}
          />
        </label>
      )}
    </div>
  );
};

export default EditableImage;