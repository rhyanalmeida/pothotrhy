import React, { useState, useCallback } from 'react';
import { Lock } from 'lucide-react';

interface StaffPortalProps {
  className?: string;
}

const StaffPortal: React.FC<StaffPortalProps> = ({ className = '' }) => {
  const [showPrompt, setShowPrompt] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const STAFF_PASSWORD = 'fhIo_*2';
  const DRIVE_URL = 'https://drive.google.com/drive/folders/1bse9xyiFzT4kQRvQEzMzuniYHmeYHsRn?usp=drive_link';

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSubmitting) return;
    setIsSubmitting(true);

    try {
      if (password === STAFF_PASSWORD) {
        window.open(DRIVE_URL, '_blank');
        setShowPrompt(false);
        setPassword('');
        setError('');
      } else {
        setError('Invalid password');
        setPassword('');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  }, [password, isSubmitting]);

  const handleClose = useCallback(() => {
    setShowPrompt(false);
    setPassword('');
    setError('');
  }, []);

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setShowPrompt(true)}
        className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
      >
        <Lock size={16} />
        Staff Portal
      </button>

      {showPrompt && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
          onClick={handleClose}
        >
          <div 
            className="bg-white rounded-lg p-6 w-full max-w-md mx-4"
            onClick={e => e.stopPropagation()}
          >
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Staff Portal Access</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="staff-password" className="block text-sm font-medium text-gray-700">
                  Enter Password
                </label>
                <input
                  id="staff-password"
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError('');
                  }}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-brown-500 focus:ring-brand-brown-500"
                  autoFocus
                  required
                  disabled={isSubmitting}
                />
                {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
              </div>
              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={handleClose}
                  className="px-4 py-2 text-gray-700 hover:text-gray-900"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`bg-brand-brown-600 text-white px-4 py-2 rounded-md transition-colors ${
                    isSubmitting 
                      ? 'opacity-50 cursor-not-allowed' 
                      : 'hover:bg-brand-brown-700'
                  }`}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Accessing...' : 'Access Portal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StaffPortal;