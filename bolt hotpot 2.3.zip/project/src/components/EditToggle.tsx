import React from 'react';
import { Edit } from 'lucide-react';
import { useEdit } from '../contexts/EditContext';

const EditToggle: React.FC = () => {
  const { isEditing, setIsEditing, isAdmin } = useEdit();

  if (!isAdmin) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <button
        onClick={() => setIsEditing(!isEditing)}
        className="bg-brand-brown-600 text-white p-3 rounded-full hover:bg-brand-brown-700 transition-colors shadow-lg"
      >
        <Edit size={24} />
      </button>
    </div>
  );
};

export default EditToggle;