import React from 'react';
import { FileUp, Download } from 'lucide-react';
import { useEdit } from '../contexts/EditContext';

interface MenuSectionProps {
  title: string;
  id: string;
  pdfUrl: string | null;
  onUpload: (categoryId: string, file: File) => void;
}

const MenuSection: React.FC<MenuSectionProps> = ({ title, id, pdfUrl, onUpload }) => {
  const { isAdmin } = useEdit();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      onUpload(id, file);
    } else {
      alert('Please upload a PDF file');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold text-brand-brown-600 mb-4">{title}</h2>
      
      <div className="border-2 border-dashed border-gray-200 rounded-lg p-8">
        {pdfUrl ? (
          <div className="space-y-4">
            <iframe
              src={pdfUrl}
              className="w-full h-[500px] border-0 rounded-lg"
              title={title}
            />
            <div className="flex justify-between items-center">
              <a
                href={pdfUrl}
                download={`${title}.pdf`}
                className="flex items-center gap-2 text-brand-brown-600 hover:text-brand-brown-700"
              >
                <Download className="w-5 h-5" />
                Download PDF
              </a>
              
              {isAdmin && (
                <label className="flex items-center gap-2 bg-brand-brown-600 text-white px-4 py-2 rounded-lg cursor-pointer hover:bg-brand-brown-700 transition-colors">
                  <FileUp className="w-5 h-5" />
                  Update PDF
                  <input
                    type="file"
                    accept="application/pdf"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            {isAdmin ? (
              <label className="inline-flex flex-col items-center cursor-pointer">
                <FileUp className="w-12 h-12 text-gray-400 mb-2" />
                <span className="text-gray-600">Upload PDF Menu</span>
                <input
                  type="file"
                  accept="application/pdf"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>
            ) : (
              <div className="text-gray-500">
                <FileUp className="w-12 h-12 mx-auto mb-2" />
                <p>Menu PDF not available yet</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default MenuSection;