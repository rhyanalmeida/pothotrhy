import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, LogOut } from 'lucide-react';
import { useEdit } from '../contexts/EditContext';

const AdminLogin = () => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login, logout, isAdmin } = useEdit();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(password);
    if (success) {
      navigate('/admin');
    } else {
      setError('Invalid password');
      setPassword('');
    }
  };

  if (isAdmin) {
    return (
      <button
        onClick={logout}
        className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
      >
        <LogOut size={16} />
        Admin Logout
      </button>
    );
  }

  return (
    <div className="relative group">
      <button
        className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
        onClick={() => document.getElementById('admin-password')?.focus()}
      >
        <Lock size={16} />
        Admin Portal
      </button>
      
      <div className="absolute bottom-full right-0 mb-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <form 
          onSubmit={handleSubmit}
          className="bg-white rounded-lg shadow-lg p-4 w-64"
        >
          <div className="space-y-3">
            <label className="block">
              <span className="text-gray-700 text-sm font-medium">Admin Password</span>
              <input
                id="admin-password"
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-brown-500 focus:ring focus:ring-brand-brown-200 focus:ring-opacity-50"
                required
              />
            </label>
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <button
              type="submit"
              className="w-full bg-brand-brown-600 text-white py-2 px-4 rounded-md hover:bg-brand-brown-700 transition-colors text-sm"
            >
              Login
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;