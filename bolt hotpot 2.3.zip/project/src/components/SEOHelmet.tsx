import React, { useEffect } from 'react';

interface SEOHelmetProps {
  title: string;
  description: string;
  path: string;
  image?: string;
}

const SEOHelmet: React.FC<SEOHelmetProps> = ({
  title,
  description,
  path,
  image = "https://i.postimg.cc/d3k3n5Xd/coverim.jpg"
}) => {
  const baseUrl = "https://hotpotone.com";
  const fullUrl = `${baseUrl}${path}`;
  const fullTitle = `${title} | Hot Pot One - Quincy, MA`;

  useEffect(() => {
    document.title = fullTitle;
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", description);
    }

    const ogTitle = document.querySelector('meta[property="og:title"]');
    const ogDescription = document.querySelector('meta[property="og:description"]');
    const ogUrl = document.querySelector('meta[property="og:url"]');
    const ogImage = document.querySelector('meta[property="og:image"]');

    if (ogTitle) ogTitle.setAttribute("content", fullTitle);
    if (ogDescription) ogDescription.setAttribute("content", description);
    if (ogUrl) ogUrl.setAttribute("content", fullUrl);
    if (ogImage) ogImage.setAttribute("content", image);

    const twitterTitle = document.querySelector('meta[property="twitter:title"]');
    const twitterDescription = document.querySelector('meta[property="twitter:description"]');
    const twitterUrl = document.querySelector('meta[property="twitter:url"]');
    const twitterImage = document.querySelector('meta[property="twitter:image"]');

    if (twitterTitle) twitterTitle.setAttribute("content", fullTitle);
    if (twitterDescription) twitterDescription.setAttribute("content", description);
    if (twitterUrl) twitterUrl.setAttribute("content", fullUrl);
    if (twitterImage) twitterImage.setAttribute("content", image);
  }, [title, description, path, image, fullTitle, fullUrl]);

  return null;
};

export default SEOHelmet;