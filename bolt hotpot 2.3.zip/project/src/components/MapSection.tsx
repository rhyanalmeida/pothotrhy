import React from 'react';
import { MapPin, Phone } from 'lucide-react';
import { EditProvider } from '../contexts/EditContext';
import EditableText from './EditableText';
import EditToggle from './EditToggle';

const MapSection = () => {
  return (
    <EditProvider>
      <div className="bg-white py-8 md:py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            <div className="space-y-6 order-2 md:order-1">
              <h2 className="text-2xl md:text-3xl font-bold text-brand-brown-600">Visit Us</h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <MapPin className="w-5 h-5 md:w-6 md:h-6 text-brand-brown-600 mt-1" />
                  <div>
                    <h3 className="font-semibold">Address</h3>
                    <EditableText
                      text="9 Billings Road"
                      onTextChange={() => {}}
                      className="text-gray-600"
                    />
                    <EditableText
                      text="Quincy, MA 02171"
                      onTextChange={() => {}}
                      className="text-gray-600"
                    />
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Phone className="w-5 h-5 md:w-6 md:h-6 text-brand-brown-600 mt-1" />
                  <div>
                    <h3 className="font-semibold">Phone</h3>
                    <EditableText
                      text="(857)-387-2000"
                      onTextChange={() => {}}
                      className="text-gray-600"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="h-[300px] md:h-[400px] rounded-lg overflow-hidden shadow-lg order-1 md:order-2">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2950.1002403910544!2d-71.02243812342755!3d42.25170994747961!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89e37d11239b451f%3A0x7c6f0d32b5c7fc6e!2s9%20Billings%20Rd%2C%20Quincy%2C%20MA%2002171!5e0!3m2!1sen!2sus!4v1710644774906!5m2!1sen!2sus"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Hotpot One Location"
              ></iframe>
            </div>
          </div>
        </div>
      </div>
      <EditToggle />
    </EditProvider>
  );
};

export default MapSection;