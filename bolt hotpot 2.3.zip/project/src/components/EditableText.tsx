import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useEdit } from '../contexts/EditContext';

interface EditableTextProps {
  text: string;
  onTextChange: (newText: string) => void;
  className?: string;
  as?: keyof JSX.IntrinsicElements;
  multiline?: boolean;
  placeholder?: string;
  id?: string;
}

const EditableText: React.FC<EditableTextProps> = ({
  text: initialText,
  onTextChange,
  className = '',
  as: Component = 'p',
  multiline = false,
  placeholder = 'Click to edit',
  id
}) => {
  const { isEditing, saveChanges, getChanges } = useEdit();
  const [isActive, setIsActive] = useState(false);
  const [editableText, setEditableText] = useState(initialText);
  const [isSaving, setIsSaving] = useState(false);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);
  const textId = id || `editable-${Math.random().toString(36).substr(2, 9)}`;

  useEffect(() => {
    const loadSavedText = async () => {
      try {
        const savedText = await getChanges(textId);
        if (savedText) {
          setEditableText(savedText);
        }
      } catch (error) {
        console.error('Error loading saved text:', error);
      }
    };

    loadSavedText();
  }, [textId, getChanges]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setEditableText(e.target.value);
  };

  const handleSave = useCallback(async () => {
    if (editableText === initialText) {
      setIsActive(false);
      return;
    }

    setIsSaving(true);
    try {
      await saveChanges(textId, editableText);
      onTextChange(editableText);
    } catch (error) {
      console.error('Error saving text:', error);
      // Optionally revert to initial text on error
      setEditableText(initialText);
    } finally {
      setIsSaving(false);
      setIsActive(false);
    }
  }, [editableText, initialText, onTextChange, saveChanges, textId]);

  const handleBlur = () => {
    handleSave();
  };

  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    if (e.key === 'Escape') {
      setEditableText(initialText);
      setIsActive(false);
    } else if (!multiline && e.key === 'Enter') {
      e.preventDefault();
      handleSave();
    }
  };

  if (isEditing) {
    if (isActive) {
      const InputComponent = multiline ? 'textarea' : 'input';
      return (
        <InputComponent
          ref={inputRef as any}
          value={editableText}
          onChange={handleChange}
          onBlur={handleBlur}
          onKeyDown={handleKeyDown}
          className={`${className} outline-none border-2 border-brand-brown-400 rounded px-2 py-1 bg-white w-full transition-colors focus:border-brand-brown-600 focus:ring-2 focus:ring-brand-brown-200 ${
            isSaving ? 'opacity-50 cursor-wait' : ''
          }`}
          autoFocus
          rows={multiline ? 3 : undefined}
          placeholder={placeholder}
          disabled={isSaving}
        />
      );
    }

    return (
      <div className="relative group">
        <Component
          onClick={() => !isSaving && setIsActive(true)}
          className={`${className} outline-none border-2 border-transparent hover:border-brand-brown-200 rounded px-2 cursor-text transition-all duration-200`}
        >
          {editableText || <span className="text-gray-400">{placeholder}</span>}
        </Component>
        <div className="absolute -top-6 left-0 bg-brand-brown-600 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
          Click to edit
        </div>
      </div>
    );
  }

  return (
    <Component className={className}>
      {editableText || placeholder}
    </Component>
  );
};

export default EditableText;