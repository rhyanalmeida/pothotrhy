import React from 'react';
import ImageUpload from './ImageUpload';

interface ImageUploadGridProps {
  images: { id: string; url: string }[];
  onImageUpload: (id: string, file: File) => void;
  className?: string;
}

const ImageUploadGrid: React.FC<ImageUploadGridProps> = ({
  images,
  onImageUpload,
  className = ''
}) => {
  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 ${className}`}>
      {images.map((image) => (
        <ImageUpload
          key={image.id}
          currentImage={image.url}
          onImageUpload={(file) => onImageUpload(image.id, file)}
          aspectRatio={16/9}
        />
      ))}
    </div>
  );
};

export default ImageUploadGrid;