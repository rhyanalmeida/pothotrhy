import React, { createContext, useContext, useState, useEffect } from 'react';
import { initializeDatabase, getStore } from '../utils/indexedDB';

interface EditContextType {
  isEditing: boolean;
  setIsEditing: (value: boolean) => void;
  isAdmin: boolean;
  login: (password: string) => boolean;
  logout: () => void;
  saveChanges: (key: string, value: any) => Promise<void>;
  getChanges: (key: string) => Promise<any>;
}

const EditContext = createContext<EditContextType | undefined>(undefined);

const ADMIN_PASSWORD = 'Potgi7&';
const STORE_NAME = 'edits';

export const EditProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [db, setDB] = useState<IDBDatabase | null>(null);

  useEffect(() => {
    const adminStatus = localStorage.getItem('isAdmin') === 'true';
    setIsAdmin(adminStatus);
    setIsEditing(false);

    const initDB = async () => {
      try {
        const database = await initializeDatabase('EditDB', STORE_NAME);
        setDB(database);
      } catch (error) {
        console.error('Error initializing EditDB:', error);
      }
    };

    initDB();

    return () => {
      if (db) {
        db.close();
      }
    };
  }, []);

  const login = (password: string) => {
    if (password === ADMIN_PASSWORD) {
      setIsAdmin(true);
      setIsEditing(false);
      localStorage.setItem('isAdmin', 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAdmin(false);
    setIsEditing(false);
    localStorage.removeItem('isAdmin');
  };

  const saveChanges = async (key: string, value: any) => {
    if (!db) throw new Error('Database not initialized');

    return new Promise<void>((resolve, reject) => {
      try {
        const store = getStore(db, STORE_NAME, 'readwrite');
        
        const editData = {
          key,
          value,
          timestamp: Date.now()
        };

        const request = store.put(editData);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      } catch (error) {
        reject(error);
      }
    });
  };

  const getChanges = async (key: string) => {
    if (!db) return null;

    return new Promise((resolve, reject) => {
      try {
        const store = getStore(db, STORE_NAME);
        const request = store.get(key);

        request.onsuccess = () => resolve(request.result?.value ?? null);
        request.onerror = () => reject(request.error);
      } catch (error) {
        reject(error);
      }
    });
  };

  const value = {
    isEditing,
    setIsEditing,
    isAdmin,
    login,
    logout,
    saveChanges,
    getChanges
  };

  return (
    <EditContext.Provider value={value}>
      {children}
    </EditContext.Provider>
  );
};

export const useEdit = () => {
  const context = useContext(EditContext);
  if (context === undefined) {
    throw new Error('useEdit must be used within an EditProvider');
  }
  return context;
};