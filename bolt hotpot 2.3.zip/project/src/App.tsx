import React, { Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import ErrorBoundary from './components/ErrorBoundary';
import { EditProvider } from './contexts/EditContext';

// Lazy load non-critical routes
const Menu = React.lazy(() => import('./pages/Menu'));
const Order = React.lazy(() => import('./pages/Order'));
const Gallery = React.lazy(() => import('./pages/Gallery'));
const Reviews = React.lazy(() => import('./pages/Reviews'));
const Staff = React.lazy(() => import('./pages/Staff'));
const Admin = React.lazy(() => import('./pages/Admin'));
const Privacy = React.lazy(() => import('./pages/Privacy'));

// Loading fallback
const LoadingFallback = () => (
  <div className="min-h-screen flex items-center justify-center">
    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-brand-brown-600"></div>
  </div>
);

function App() {
  return (
    <ErrorBoundary>
      <EditProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Navbar />
            <Suspense fallback={<LoadingFallback />}>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/menu" element={<Menu />} />
                <Route path="/order" element={<Order />} />
                <Route path="/gallery" element={<Gallery />} />
                <Route path="/reviews" element={<Reviews />} />
                <Route path="/staff" element={<Staff />} />
                <Route path="/admin" element={<Admin />} />
                <Route path="/privacy" element={<Privacy />} />
              </Routes>
            </Suspense>
          </div>
        </Router>
      </EditProvider>
    </ErrorBoundary>
  );
}

export default App;