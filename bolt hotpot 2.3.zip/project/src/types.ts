export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image?: string;
}

export interface Review {
  id?: string;
  author: string;
  content: string;
  rating: number;
  date: string;
  timestamp: number;
}