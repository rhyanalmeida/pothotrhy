export const initializeDatabase = (dbName: string, storeName: string, options: { keyPath?: string } = {}) => {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(dbName, 13); // Increment version for clean upgrade
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      // Delete old store if it exists to ensure clean state
      if (db.objectStoreNames.contains(storeName)) {
        db.deleteObjectStore(storeName);
      }

      // Create store with consistent configuration
      const storeConfig = options.keyPath ? { keyPath: options.keyPath } : { autoIncrement: true };
      const store = db.createObjectStore(storeName, storeConfig);
      
      // Add required indexes
      store.createIndex('timestamp', 'timestamp', { unique: false });
      
      // Add additional indexes based on store type
      if (storeName === 'reviews') {
        store.createIndex('rating', 'rating', { unique: false });
      } else if (storeName === 'images') {
        store.createIndex('category', 'category', { unique: false });
      }
    };
  });
};

export const getStore = (db: IDBDatabase, storeName: string, mode: IDBTransactionMode = 'readonly') => {
  try {
    const transaction = db.transaction(storeName, mode);
    return transaction.objectStore(storeName);
  } catch (error) {
    console.error(`Error accessing store ${storeName}:`, error);
    throw new Error(`Failed to access store ${storeName}`);
  }
};

export const saveImage = async (db: IDBDatabase, imageData: {
  dataUrl: string;
  alt: string;
  category?: string;
}) => {
  return new Promise<number>((resolve, reject) => {
    try {
      const store = getStore(db, 'images', 'readwrite');
      const request = store.add({
        ...imageData,
        timestamp: Date.now(),
        category: imageData.category || 'general'
      });

      request.onsuccess = () => resolve(request.result as number);
      request.onerror = () => reject(request.error);
    } catch (error) {
      reject(error);
    }
  });
};

export const getImages = async (db: IDBDatabase, category?: string) => {
  return new Promise<any[]>((resolve, reject) => {
    try {
      const store = getStore(db, 'images');
      const index = store.index('timestamp');
      const request = category 
        ? index.openCursor(IDBKeyRange.only(category), 'prev')
        : index.openCursor(null, 'prev');

      const images: any[] = [];

      request.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest).result;
        if (cursor) {
          images.push(cursor.value);
          cursor.continue();
        } else {
          resolve(images);
        }
      };

      request.onerror = () => reject(request.error);
    } catch (error) {
      reject(error);
    }
  });
};

export const deleteImage = async (db: IDBDatabase, id: number) => {
  return new Promise<void>((resolve, reject) => {
    try {
      const store = getStore(db, 'images', 'readwrite');
      const request = store.delete(id);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    } catch (error) {
      reject(error);
    }
  });
};

export const clearDatabase = async (dbName: string) => {
  return new Promise<void>((resolve, reject) => {
    const request = indexedDB.deleteDatabase(dbName);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
};

export const migrateData = async (oldDb: IDBDatabase, newDb: IDBDatabase, storeName: string) => {
  const oldStore = getStore(oldDb, storeName);
  const newStore = getStore(newDb, storeName, 'readwrite');
  
  return new Promise<void>((resolve, reject) => {
    const request = oldStore.getAll();
    
    request.onsuccess = () => {
      const data = request.result;
      data.forEach(item => newStore.add(item));
      resolve();
    };
    
    request.onerror = () => reject(request.error);
  });
};