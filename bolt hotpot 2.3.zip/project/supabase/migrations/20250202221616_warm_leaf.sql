/*
  # Fix Announcements RLS Policies - Final Update

  1. Changes
    - Drop existing policies
    - Create new comprehensive RLS policies for announcements table
    
  2. Security
    - Enable RLS on announcements table
    - Add policies for:
      - Public read access to public announcements
      - Full CRUD access for authenticated users
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Public can view public announcements" ON announcements;
DROP POLICY IF EXISTS "Authenticated users can manage announcements" ON announcements;

-- Create new comprehensive policies
CREATE POLICY "Public can view public announcements"
  ON announcements
  FOR SELECT
  TO PUBLIC
  USING (is_public = true);

CREATE POLICY "Authenticated users can manage announcements"
  ON announcements
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Ensure initial announcement exists
INSERT INTO announcements (id, content, is_public)
VALUES (
  'current',
  'Welcome to Hot Pot One! We''re excited to announce our new seasonal menu items. Come try our special winter broths and premium ingredients.',
  true
) ON CONFLICT (id) DO UPDATE SET
  content = EXCLUDED.content,
  is_public = EXCLUDED.is_public;