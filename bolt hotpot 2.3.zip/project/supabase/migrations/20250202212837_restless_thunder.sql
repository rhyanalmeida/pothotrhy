/*
  # Initial Schema Setup

  1. New Tables
    - `announcements`
      - `id` (uuid, primary key)
      - `content` (text)
      - `is_public` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    - `reviews`
      - `id` (uuid, primary key)
      - `author` (text)
      - `content` (text)
      - `rating` (integer)
      - `created_at` (timestamp)
    - `images`
      - `id` (uuid, primary key)
      - `url` (text)
      - `alt` (text)
      - `category` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create announcements table
CREATE TABLE IF NOT EXISTS announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content text NOT NULL,
  is_public boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author text NOT NULL,
  content text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  created_at timestamptz DEFAULT now()
);

-- Create images table
CREATE TABLE IF NOT EXISTS images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  alt text NOT NULL,
  category text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE images ENABLE ROW LEVEL SECURITY;

-- Announcements policies
CREATE POLICY "Anyone can view public announcements"
  ON announcements
  FOR SELECT
  USING (is_public = true);

CREATE POLICY "Authenticated users can manage announcements"
  ON announcements
  USING (auth.role() = 'authenticated');

-- Reviews policies
CREATE POLICY "Anyone can view reviews"
  ON reviews
  FOR SELECT
  TO PUBLIC;

CREATE POLICY "Anyone can create reviews"
  ON reviews
  FOR INSERT
  TO PUBLIC;

-- Images policies
CREATE POLICY "Anyone can view images"
  ON images
  FOR SELECT
  TO PUBLIC;

CREATE POLICY "Authenticated users can manage images"
  ON images
  USING (auth.role() = 'authenticated');