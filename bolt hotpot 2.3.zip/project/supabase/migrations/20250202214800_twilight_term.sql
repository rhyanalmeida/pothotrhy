/*
  # Create editable content table

  1. New Tables
    - `editable_content`
      - `id` (text, primary key) - Identifier for the content section
      - `content` (text) - The actual content
      - `updated_at` (timestamp) - Last update timestamp
      - `created_at` (timestamp) - Creation timestamp

  2. Security
    - Enable RLS
    - Add policies for authenticated users to manage content
    - Allow public read access
*/

CREATE TABLE IF NOT EXISTS editable_content (
  id text PRIMARY KEY,
  content text NOT NULL,
  updated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE editable_content ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read access to editable content"
  ON editable_content
  FOR SELECT
  TO PUBLIC
  USING (true);

CREATE POLICY "Allow authenticated users to manage editable content"
  ON editable_content
  USING (auth.role() = 'authenticated');

-- Insert initial content
INSERT INTO editable_content (id, content)
VALUES (
  'menu-description',
  'Explore our carefully curated selection of hot pot broths, fresh ingredients, dim sum specialties, and refreshing beverages.'
) ON CONFLICT (id) DO NOTHING;