/*
  # Fix Announcements RLS Policies - Final Update

  1. Changes
    - Drop all existing policies
    - Create new comprehensive RLS policies for announcements table
    
  2. Security
    - Enable RLS on announcements table
    - Add policies for:
      - Public read access to public announcements
      - Full CRUD access for authenticated users with proper USING and WITH CHECK clauses
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view public announcements" ON announcements;
DROP POLICY IF EXISTS "Authenticated users can read all announcements" ON announcements;
DROP POLICY IF EXISTS "Authenticated users can insert announcements" ON announcements;
DROP POLICY IF EXISTS "Authenticated users can update announcements" ON announcements;
DROP POLICY IF EXISTS "Authenticated users can delete announcements" ON announcements;

-- Create new comprehensive policies
CREATE POLICY "Public can view public announcements"
  ON announcements
  FOR SELECT
  TO PUBLIC
  USING (is_public = true);

CREATE POLICY "Authenticated users can manage announcements"
  ON announcements
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);