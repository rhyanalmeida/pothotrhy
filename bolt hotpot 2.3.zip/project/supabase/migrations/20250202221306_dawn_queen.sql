/*
  # Fix Announcements RLS Policies

  1. Changes
    - Drop existing policies to ensure clean state
    - Create new comprehensive RLS policies for announcements table
    
  2. Security
    - Enable RLS on announcements table
    - Add policies for:
      - Public read access to public announcements
      - Full CRUD access for authenticated users
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view public announcements" ON announcements;
DROP POLICY IF EXISTS "Authenticated users can manage announcements" ON announcements;

-- Create new policies
CREATE POLICY "Anyone can view public announcements"
  ON announcements
  FOR SELECT
  TO PUBLIC
  USING (is_public = true);

CREATE POLICY "Authenticated users can read all announcements"
  ON announcements
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert announcements"
  ON announcements
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update announcements"
  ON announcements
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete announcements"
  ON announcements
  FOR DELETE
  TO authenticated
  USING (true);