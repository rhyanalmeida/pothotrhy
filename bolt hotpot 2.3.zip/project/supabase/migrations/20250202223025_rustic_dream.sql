/*
  # Fix announcements table and policies

  1. Changes
    - Drop existing policies if they exist
    - Recreate policies with proper checks
    - Update initial announcement

  2. Security
    - Maintain RLS on announcements table
    - Ensure proper access control for public and authenticated users
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'announcements' 
    AND schemaname = 'public'
  ) THEN
    DROP POLICY IF EXISTS "Public can view public announcements" ON announcements;
    DROP POLICY IF EXISTS "Authenticated users can manage announcements" ON announcements;
  END IF;
END $$;

-- Create new policies
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'announcements' 
    AND policyname = 'Public can view public announcements'
  ) THEN
    CREATE POLICY "Public can view public announcements"
      ON announcements
      FOR SELECT
      TO PUBLIC
      USING (is_public = true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'announcements' 
    AND policyname = 'Authenticated users can manage announcements'
  ) THEN
    CREATE POLICY "Authenticated users can manage announcements"
      ON announcements
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Update initial announcement
INSERT INTO announcements (id, content, is_public)
VALUES (
  'current',
  'Welcome to Hot Pot One! We''re excited to announce our new seasonal menu items. Come try our special winter broths and premium ingredients.',
  true
) ON CONFLICT (id) DO UPDATE SET
  content = EXCLUDED.content,
  is_public = EXCLUDED.is_public;