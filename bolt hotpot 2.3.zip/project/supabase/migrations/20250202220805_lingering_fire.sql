/*
  # Create announcements table with text ID

  1. Changes
    - Create announcements table with text-based ID
    - Add RLS policies for public and authenticated access
  
  2. Security
    - Enable RLS
    - Public can view public announcements
    - Authenticated users can manage all announcements
*/

-- Create announcements table
CREATE TABLE IF NOT EXISTS announcements (
  id text PRIMARY KEY,
  content text NOT NULL,
  is_public boolean DEFAULT false,
  updated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;

-- Create policies if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'announcements' 
    AND policyname = 'Anyone can view public announcements'
  ) THEN
    CREATE POLICY "Anyone can view public announcements"
      ON announcements
      FOR SELECT
      TO PUBLIC
      USING (is_public = true);
  END IF;
END $$;

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'announcements' 
    AND policyname = 'Authenticated users can manage announcements'
  ) THEN
    CREATE POLICY "Authenticated users can manage announcements"
      ON announcements
      FOR ALL
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Insert initial announcement if it doesn't exist
INSERT INTO announcements (id, content, is_public)
VALUES (
  'current',
  'Welcome to Hot Pot One! We''re excited to announce our new seasonal menu items. Come try our special winter broths and premium ingredients.',
  true
) ON CONFLICT (id) DO NOTHING;