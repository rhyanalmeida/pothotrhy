-- Create editable_content table with text ID
CREATE TABLE IF NOT EXISTS editable_content (
  id text PRIMARY KEY,
  content text NOT NULL,
  updated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE editable_content ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read access to editable content"
  ON editable_content
  FOR SELECT
  TO PUBLIC
  USING (true);

CREATE POLICY "Allow authenticated users to manage editable content"
  ON editable_content
  USING (auth.role() = 'authenticated');

-- Insert initial content
INSERT INTO editable_content (id, content)
VALUES (
  'menu-description',
  'Explore our carefully curated selection of hot pot broths, fresh ingredients, dim sum specialties, and refreshing beverages.'
) ON CONFLICT (id) DO NOTHING;